/*
 Navicat MySQL Data Transfer

 Source Server         : Whb
 Source Server Type    : MySQL
 Source Server Version : 80028
 Source Host           : localhost:3306
 Source Schema         : dormitory

 Target Server Type    : MySQL
 Target Server Version : 80028
 File Encoding         : 65001

 Date: 14/05/2022 14:34:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for dt_absence
-- ----------------------------
DROP TABLE IF EXISTS `dt_absence`;
CREATE TABLE `dt_absence`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `building_id` int(0) NULL DEFAULT NULL,
  `storey_id` int(0) NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `student_id` int(0) NULL DEFAULT NULL,
  `late_time` date NULL DEFAULT NULL,
  `remark` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_absence
-- ----------------------------
INSERT INTO `dt_absence` VALUES (1, 1, 1, 1, 1, '2022-03-01', '');
INSERT INTO `dt_absence` VALUES (2, 1, 1, 5, 2, '2022-04-01', '');

-- ----------------------------
-- Table structure for dt_bed
-- ----------------------------
DROP TABLE IF EXISTS `dt_bed`;
CREATE TABLE `dt_bed`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `bno` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `building_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_bed
-- ----------------------------
INSERT INTO `dt_bed` VALUES (1, '1', 1, 1);
INSERT INTO `dt_bed` VALUES (2, '2', 1, 1);
INSERT INTO `dt_bed` VALUES (3, '3', 1, 1);
INSERT INTO `dt_bed` VALUES (4, '4', 1, 1);
INSERT INTO `dt_bed` VALUES (5, '5', 1, 1);
INSERT INTO `dt_bed` VALUES (6, '6', 1, 1);
INSERT INTO `dt_bed` VALUES (7, '1', 2, 2);
INSERT INTO `dt_bed` VALUES (8, '2', 2, 2);
INSERT INTO `dt_bed` VALUES (9, '3', 2, 2);
INSERT INTO `dt_bed` VALUES (10, '4', 2, 2);
INSERT INTO `dt_bed` VALUES (11, '5', 2, 2);
INSERT INTO `dt_bed` VALUES (12, '6', 2, 2);
INSERT INTO `dt_bed` VALUES (13, '1', 3, 3);
INSERT INTO `dt_bed` VALUES (14, '2', 3, 3);
INSERT INTO `dt_bed` VALUES (15, '3', 3, 3);
INSERT INTO `dt_bed` VALUES (16, '4', 3, 3);
INSERT INTO `dt_bed` VALUES (17, '5', 3, 3);
INSERT INTO `dt_bed` VALUES (18, '6', 3, 3);
INSERT INTO `dt_bed` VALUES (19, '1', 4, 4);
INSERT INTO `dt_bed` VALUES (20, '2', 4, 4);
INSERT INTO `dt_bed` VALUES (21, '3', 4, 4);
INSERT INTO `dt_bed` VALUES (22, '4', 4, 4);
INSERT INTO `dt_bed` VALUES (23, '5', 4, 4);
INSERT INTO `dt_bed` VALUES (24, '6', 4, 4);
INSERT INTO `dt_bed` VALUES (25, '1', 5, 1);
INSERT INTO `dt_bed` VALUES (26, '2', 5, 1);
INSERT INTO `dt_bed` VALUES (27, '3', 5, 1);
INSERT INTO `dt_bed` VALUES (28, '4', 5, 1);
INSERT INTO `dt_bed` VALUES (29, '5', 5, 1);
INSERT INTO `dt_bed` VALUES (30, '6', 5, 1);

-- ----------------------------
-- Table structure for dt_bill
-- ----------------------------
DROP TABLE IF EXISTS `dt_bill`;
CREATE TABLE `dt_bill`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `student_id` int(0) NULL DEFAULT NULL,
  `type` int(0) NULL DEFAULT NULL,
  `classification` int(0) NULL DEFAULT NULL,
  `money` double NULL DEFAULT NULL,
  `spend_content` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `spend_time` datetime(0) NULL DEFAULT NULL,
  `balance` double NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_bill
-- ----------------------------
INSERT INTO `dt_bill` VALUES (1, 1, 1, 1, 4, 1200, '宿舍费用', '2022-01-01 21:09:58', 1200);
INSERT INTO `dt_bill` VALUES (2, 1, 1, 0, 0, 50, '水费', '2022-01-05 21:10:50', 1150);
INSERT INTO `dt_bill` VALUES (3, 1, 1, 0, 0, 256, '电费', '2022-01-12 21:11:43', 894);
INSERT INTO `dt_bill` VALUES (4, 1, 1, 0, 1, 494, '海底捞', '2022-01-21 21:13:14', 400);
INSERT INTO `dt_bill` VALUES (5, 1, 1, 0, 2, 45, 'Java编程课本', '2022-01-23 22:14:07', 355);
INSERT INTO `dt_bill` VALUES (6, 1, 3, 0, 3, 100, '玩桌游', '2022-01-24 21:16:13', 255);
INSERT INTO `dt_bill` VALUES (7, 1, 3, 1, 4, 1200, '宿舍费用', '2022-02-01 21:17:28', 1455);
INSERT INTO `dt_bill` VALUES (8, 1, 3, 0, 0, 55, '水费', '2022-02-07 21:27:52', 1400);
INSERT INTO `dt_bill` VALUES (9, 1, 3, 0, 0, 260, '电费', '2022-02-16 21:48:37', 1140);
INSERT INTO `dt_bill` VALUES (10, 1, 3, 0, 1, 300, '烧烤', '2022-02-20 21:53:50', 840);
INSERT INTO `dt_bill` VALUES (11, 1, 3, 0, 2, 70, '操作系统', '2022-02-23 22:18:14', 770);
INSERT INTO `dt_bill` VALUES (12, 1, 3, 0, 3, 500, '看电影', '2022-02-28 21:54:35', 270);
INSERT INTO `dt_bill` VALUES (13, 1, 4, 1, 4, 900, '宿舍费用', '2022-03-01 21:55:10', 1170);
INSERT INTO `dt_bill` VALUES (14, 1, 4, 0, 0, 20, '水费', '2022-03-10 21:55:58', 1150);
INSERT INTO `dt_bill` VALUES (15, 1, 4, 0, 0, 250, '电费', '2022-03-18 21:56:08', 900);
INSERT INTO `dt_bill` VALUES (16, 1, 4, 0, 1, 500, '椰子鸡', '2022-03-21 21:56:41', 400);
INSERT INTO `dt_bill` VALUES (17, 1, 4, 0, 2, 80, 'Python入门', '2022-03-24 22:21:46', 320);
INSERT INTO `dt_bill` VALUES (18, 1, 4, 0, 3, 100, '上网', '2022-03-25 21:57:06', 220);
INSERT INTO `dt_bill` VALUES (19, 1, 5, 1, 4, 900, '宿舍费用', '2022-04-01 22:02:09', 1120);
INSERT INTO `dt_bill` VALUES (20, 1, 5, 0, 0, 40, '水费', '2022-04-04 22:02:20', 1080);
INSERT INTO `dt_bill` VALUES (21, 1, 5, 0, 0, 330, '电费', '2022-04-14 22:02:43', 750);
INSERT INTO `dt_bill` VALUES (22, 1, 5, 0, 1, 300, '喝酒', '2022-04-16 22:03:12', 450);
INSERT INTO `dt_bill` VALUES (23, 1, 5, 0, 2, 30, '高数4', '2022-04-18 22:03:47', 420);
INSERT INTO `dt_bill` VALUES (24, 1, 5, 0, 3, 400, '轰趴', '2022-04-19 22:24:14', 20);
INSERT INTO `dt_bill` VALUES (25, 1, 1, 1, 4, 600, '宿舍费用', '2022-05-09 23:25:13', 620);
INSERT INTO `dt_bill` VALUES (26, 1, 1, 0, 0, 120, '电费', '2022-05-09 23:45:48', 500);
INSERT INTO `dt_bill` VALUES (27, 1, 1, 0, 0, 20, '水费', '2022-05-09 23:56:32', 480);
INSERT INTO `dt_bill` VALUES (28, 1, 1, 0, 1, 300, '自助餐', '2022-05-09 23:56:58', 180);

-- ----------------------------
-- Table structure for dt_building
-- ----------------------------
DROP TABLE IF EXISTS `dt_building`;
CREATE TABLE `dt_building`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `storey_num` int(0) NULL DEFAULT NULL,
  `sex` int(0) NULL DEFAULT NULL,
  `remark` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '楼宇' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_building
-- ----------------------------
INSERT INTO `dt_building` VALUES (1, '男生宿舍1栋', 7, 1, '', 3);
INSERT INTO `dt_building` VALUES (2, '男生宿舍2栋', 7, 1, '', 3);
INSERT INTO `dt_building` VALUES (3, '女生宿舍3栋', 7, 0, '', 2);
INSERT INTO `dt_building` VALUES (4, '女生宿舍4栋', 7, 0, '', 2);

-- ----------------------------
-- Table structure for dt_class
-- ----------------------------
DROP TABLE IF EXISTS `dt_class`;
CREATE TABLE `dt_class`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `grade_id` int(0) NULL DEFAULT NULL,
  `college_id` int(0) NULL DEFAULT NULL,
  `professionalclass` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_class
-- ----------------------------
INSERT INTO `dt_class` VALUES (1, 1, 1, '软件工程1班');
INSERT INTO `dt_class` VALUES (2, 1, 1, '软件工程2班');
INSERT INTO `dt_class` VALUES (3, 1, 5, '法学1班');
INSERT INTO `dt_class` VALUES (4, 1, 7, '会计1班');
INSERT INTO `dt_class` VALUES (5, 1, 3, '航空1班');
INSERT INTO `dt_class` VALUES (6, 1, 2, '信息1班');

-- ----------------------------
-- Table structure for dt_college
-- ----------------------------
DROP TABLE IF EXISTS `dt_college`;
CREATE TABLE `dt_college`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `college` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_college
-- ----------------------------
INSERT INTO `dt_college` VALUES (1, '计算机学院');
INSERT INTO `dt_college` VALUES (2, '信息学院');
INSERT INTO `dt_college` VALUES (3, '航空学院');
INSERT INTO `dt_college` VALUES (4, '艺术学院');
INSERT INTO `dt_college` VALUES (5, '法律学院');
INSERT INTO `dt_college` VALUES (6, '机械工程学院');
INSERT INTO `dt_college` VALUES (7, '会计学院');

-- ----------------------------
-- Table structure for dt_dormitory
-- ----------------------------
DROP TABLE IF EXISTS `dt_dormitory`;
CREATE TABLE `dt_dormitory`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `no` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` int(0) NULL DEFAULT NULL,
  `capacity` int(0) NULL DEFAULT NULL,
  `storey_id` int(0) NULL DEFAULT NULL,
  `building_id` int(0) NULL DEFAULT NULL,
  `balance` double NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_dormitory
-- ----------------------------
INSERT INTO `dt_dormitory` VALUES (1, '101', 1, 6, 1, 1, 180);
INSERT INTO `dt_dormitory` VALUES (2, '101', 1, 6, 8, 2, 0);
INSERT INTO `dt_dormitory` VALUES (3, '101', 0, 6, 15, 3, 0);
INSERT INTO `dt_dormitory` VALUES (4, '101', 0, 6, 22, 4, 0);
INSERT INTO `dt_dormitory` VALUES (5, '102', 1, 6, 1, 1, 0);

-- ----------------------------
-- Table structure for dt_dormitory_student
-- ----------------------------
DROP TABLE IF EXISTS `dt_dormitory_student`;
CREATE TABLE `dt_dormitory_student`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `bed_id` int(0) NULL DEFAULT NULL,
  `student_id` int(0) NULL DEFAULT NULL,
  `select_time` datetime(0) NULL DEFAULT NULL,
  `status` int(0) NULL DEFAULT NULL COMMENT '0待入住/1已入住',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_dormitory_student
-- ----------------------------
INSERT INTO `dt_dormitory_student` VALUES (1, 1, 1, 1, '2022-03-23 18:17:38', 1);
INSERT INTO `dt_dormitory_student` VALUES (2, 5, 25, 2, '2022-04-01 17:42:30', 1);
INSERT INTO `dt_dormitory_student` VALUES (3, 1, 2, 3, '2022-04-16 12:11:30', 1);
INSERT INTO `dt_dormitory_student` VALUES (4, 1, 3, 4, '2022-04-17 13:27:27', 1);
INSERT INTO `dt_dormitory_student` VALUES (5, 1, 4, 5, '2022-04-17 13:27:47', 1);

-- ----------------------------
-- Table structure for dt_grade
-- ----------------------------
DROP TABLE IF EXISTS `dt_grade`;
CREATE TABLE `dt_grade`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `grade` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_grade
-- ----------------------------
INSERT INTO `dt_grade` VALUES (1, '2018');
INSERT INTO `dt_grade` VALUES (2, '2019');
INSERT INTO `dt_grade` VALUES (3, '2020');

-- ----------------------------
-- Table structure for dt_menu
-- ----------------------------
DROP TABLE IF EXISTS `dt_menu`;
CREATE TABLE `dt_menu`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `href` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `parent_id` int(0) NULL DEFAULT NULL,
  `type` int(0) NULL DEFAULT NULL COMMENT '0:管理员;1:学生',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_menu
-- ----------------------------
INSERT INTO `dt_menu` VALUES (1, '系统信息', 'fa fa-cog', 'information/information.html', 0, 0);
INSERT INTO `dt_menu` VALUES (2, '基础资料', 'fa fa-id-card-o', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (3, '用户管理', 'fa fa-caret-right', 'user/list.html', 2, 0);
INSERT INTO `dt_menu` VALUES (4, '年级管理', 'fa fa-caret-right', 'grade/list.html', 2, 0);
INSERT INTO `dt_menu` VALUES (5, '学院管理', 'fa fa-caret-right', 'college/list.html', 2, 0);
INSERT INTO `dt_menu` VALUES (6, '班级管理', 'fa fa-caret-right', 'class/list.html', 2, 0);
INSERT INTO `dt_menu` VALUES (7, '学生管理', 'fa fa-caret-right', 'student/list.html', 2, 0);
INSERT INTO `dt_menu` VALUES (8, '宿舍管理', 'fa fa-home', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (9, '楼宇管理', 'fa fa-caret-right', 'building/list.html', 8, 0);
INSERT INTO `dt_menu` VALUES (10, '宿舍管理', 'fa fa-caret-right', 'dormitory/list.html', 8, 0);
INSERT INTO `dt_menu` VALUES (11, '预选管理', 'fa fa-caret-right', 'primary/list.html', 8, 0);
INSERT INTO `dt_menu` VALUES (12, '水电管理', 'fa fa-caret-right', 'waterelectricity/dormitorylist.html', 8, 0);
INSERT INTO `dt_menu` VALUES (13, '晚归管理', 'fa fa-telegram', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (14, '晚归记录', 'fa fa-caret-right', 'absence/list.html', 13, 0);
INSERT INTO `dt_menu` VALUES (15, '报修管理', 'fa fa-wrench', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (16, '报修查询', 'fa fa-caret-right', 'repair/list.html', 15, 0);
INSERT INTO `dt_menu` VALUES (17, '来访管理', 'fa fa-truck', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (18, '来访登记', 'fa fa-caret-right', 'visit/list.html', 17, 0);
INSERT INTO `dt_menu` VALUES (19, '公告管理', 'fa fa-bell', NULL, 0, 0);
INSERT INTO `dt_menu` VALUES (20, '公告发布', 'fa fa-caret-right', 'notice/list.html', 19, 0);
INSERT INTO `dt_menu` VALUES (21, '基础资料', 'fa fa-id-card-o', NULL, 0, 1);
INSERT INTO `dt_menu` VALUES (22, '个人详情', 'fa fa-caret-right', 'stu/info.html', 21, 1);
INSERT INTO `dt_menu` VALUES (23, '宿舍管理', 'fa fa-home', NULL, 0, 1);
INSERT INTO `dt_menu` VALUES (24, '在线选宿舍', 'fa fa-caret-right', 'stu/select.html', 23, 1);
INSERT INTO `dt_menu` VALUES (25, '宿舍信息', 'fa fa-caret-right', 'stu/dormitoryinformation.html', 23, 1);
INSERT INTO `dt_menu` VALUES (26, '宿舍水电', 'fa fa-caret-right', 'waterelectricity/stu_waterelectricitylist.html', 23, 1);
INSERT INTO `dt_menu` VALUES (27, '宿舍账单', 'fa fa-caret-right', 'bill/list.html', 23, 1);
INSERT INTO `dt_menu` VALUES (28, '晚归管理', 'fa fa-telegram', NULL, 0, 1);
INSERT INTO `dt_menu` VALUES (29, '晚归查询', 'fa fa-caret-right', 'absence/stu_absencelist.html', 28, 1);
INSERT INTO `dt_menu` VALUES (30, '报修管理', 'fa fa-wrench', NULL, 0, 1);
INSERT INTO `dt_menu` VALUES (31, '报修申请', 'fa fa-caret-right', 'repair/stu_repairlist.html', 30, 1);
INSERT INTO `dt_menu` VALUES (32, '公告管理', 'fa fa-bell', NULL, 0, 1);
INSERT INTO `dt_menu` VALUES (33, '公告查询', 'fa fa-caret-right', 'notice/stu_noticelist.html', 32, 1);

-- ----------------------------
-- Table structure for dt_notice
-- ----------------------------
DROP TABLE IF EXISTS `dt_notice`;
CREATE TABLE `dt_notice`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `create_time` date NULL DEFAULT NULL,
  `user_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_notice
-- ----------------------------
INSERT INTO `dt_notice` VALUES (1, '上海4月1日起开展浦西地区核酸筛查 涉12个区1600万人', '新华社上海3月31日电（记者袁全）在3月31日举行的上海市新冠肺炎疫情防控新闻发布会上，上海市委副秘书长、市政府秘书长马春雷表示，4月1日起，上海浦西地区的核酸筛查将全面展开，这一批涉及人数更多（1600万人）、管控范围更大（12个区），各类情况也更复杂。对此，上海将全力加快核酸筛查工作，做好市民生活服务保障。', '2022-03-31', 1);
INSERT INTO `dt_notice` VALUES (2, '广东省2022年高校毕业生“三支一扶”计划招募公告', '根据《中共中央组织部 人力资源社会保障部等十部门关于实施第四轮高校毕业生“三支一扶”计划的通知》（人社部发〔2021〕32号）和《中共广东省委办公厅 广东省人民政府办公厅印发〈关于进一步引导和鼓励高校毕业生到基层工作的实施意见〉的通知》（粤办发〔2018〕11号），2022年我省继续选派高校毕业生到基层从事支教、支农、支医和帮扶乡村振兴等志愿服务（简称为“三支一扶”）。', '2022-04-17', 2);

-- ----------------------------
-- Table structure for dt_primary
-- ----------------------------
DROP TABLE IF EXISTS `dt_primary`;
CREATE TABLE `dt_primary`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `start_time` date NULL DEFAULT NULL,
  `end_time` date NULL DEFAULT NULL,
  `grade_id` int(0) NULL DEFAULT NULL,
  `college_id` int(0) NULL DEFAULT NULL,
  `remark` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_primary
-- ----------------------------
INSERT INTO `dt_primary` VALUES (1, '2018级计算机学院预选宿舍', '2022-01-01', '2022-05-01', 1, 1, '');
INSERT INTO `dt_primary` VALUES (2, '2018级法律学院预选宿舍', '2022-05-01', '2022-05-31', 1, 5, '');

-- ----------------------------
-- Table structure for dt_primaryclass
-- ----------------------------
DROP TABLE IF EXISTS `dt_primaryclass`;
CREATE TABLE `dt_primaryclass`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `primary_id` int(0) NULL DEFAULT NULL,
  `class_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_primaryclass
-- ----------------------------
INSERT INTO `dt_primaryclass` VALUES (5, 1, 1);
INSERT INTO `dt_primaryclass` VALUES (6, 1, 2);
INSERT INTO `dt_primaryclass` VALUES (7, 2, 3);

-- ----------------------------
-- Table structure for dt_primarydormitory
-- ----------------------------
DROP TABLE IF EXISTS `dt_primarydormitory`;
CREATE TABLE `dt_primarydormitory`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `building_id` int(0) NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `class_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_primarydormitory
-- ----------------------------
INSERT INTO `dt_primarydormitory` VALUES (1, 1, 1, 1);
INSERT INTO `dt_primarydormitory` VALUES (2, 1, 5, 1);
INSERT INTO `dt_primarydormitory` VALUES (3, 1, 1, 2);
INSERT INTO `dt_primarydormitory` VALUES (4, 1, 5, 2);
INSERT INTO `dt_primarydormitory` VALUES (5, 2, 2, 1);
INSERT INTO `dt_primarydormitory` VALUES (6, 3, 3, 1);
INSERT INTO `dt_primarydormitory` VALUES (7, 4, 4, 1);
INSERT INTO `dt_primarydormitory` VALUES (8, 2, 2, 2);
INSERT INTO `dt_primarydormitory` VALUES (9, 3, 3, 2);

-- ----------------------------
-- Table structure for dt_repair
-- ----------------------------
DROP TABLE IF EXISTS `dt_repair`;
CREATE TABLE `dt_repair`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `building_id` int(0) NULL DEFAULT NULL,
  `storey_id` int(0) NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `student_id` int(0) NULL DEFAULT NULL,
  `description` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` date NULL DEFAULT NULL,
  `status` int(0) NULL DEFAULT NULL COMMENT '0待解决/1已解决',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_repair
-- ----------------------------
INSERT INTO `dt_repair` VALUES (1, 1, 1, 1, 1, '浴室水龙头漏水', '2022-04-01', 0);
INSERT INTO `dt_repair` VALUES (2, 1, 1, 5, 2, '洗手盆漏水', '2022-04-17', 0);

-- ----------------------------
-- Table structure for dt_storey
-- ----------------------------
DROP TABLE IF EXISTS `dt_storey`;
CREATE TABLE `dt_storey`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `building_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_storey
-- ----------------------------
INSERT INTO `dt_storey` VALUES (1, '1层', 1);
INSERT INTO `dt_storey` VALUES (2, '2层', 1);
INSERT INTO `dt_storey` VALUES (3, '3层', 1);
INSERT INTO `dt_storey` VALUES (4, '4层', 1);
INSERT INTO `dt_storey` VALUES (5, '5层', 1);
INSERT INTO `dt_storey` VALUES (6, '6层', 1);
INSERT INTO `dt_storey` VALUES (7, '7层', 1);
INSERT INTO `dt_storey` VALUES (8, '1层', 2);
INSERT INTO `dt_storey` VALUES (9, '2层', 2);
INSERT INTO `dt_storey` VALUES (10, '3层', 2);
INSERT INTO `dt_storey` VALUES (11, '4层', 2);
INSERT INTO `dt_storey` VALUES (12, '5层', 2);
INSERT INTO `dt_storey` VALUES (13, '6层', 2);
INSERT INTO `dt_storey` VALUES (14, '7层', 2);
INSERT INTO `dt_storey` VALUES (15, '1层', 3);
INSERT INTO `dt_storey` VALUES (16, '2层', 3);
INSERT INTO `dt_storey` VALUES (17, '3层', 3);
INSERT INTO `dt_storey` VALUES (18, '4层', 3);
INSERT INTO `dt_storey` VALUES (19, '5层', 3);
INSERT INTO `dt_storey` VALUES (20, '6层', 3);
INSERT INTO `dt_storey` VALUES (21, '7层', 3);
INSERT INTO `dt_storey` VALUES (22, '1层', 4);
INSERT INTO `dt_storey` VALUES (23, '2层', 4);
INSERT INTO `dt_storey` VALUES (24, '3层', 4);
INSERT INTO `dt_storey` VALUES (25, '4层', 4);
INSERT INTO `dt_storey` VALUES (26, '5层', 4);
INSERT INTO `dt_storey` VALUES (27, '6层', 4);
INSERT INTO `dt_storey` VALUES (28, '7层', 4);

-- ----------------------------
-- Table structure for dt_student
-- ----------------------------
DROP TABLE IF EXISTS `dt_student`;
CREATE TABLE `dt_student`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `stu_no` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grade_id` int(0) NULL DEFAULT NULL,
  `college_id` int(0) NULL DEFAULT NULL,
  `class_id` int(0) NULL DEFAULT NULL,
  `sex` int(0) NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_student
-- ----------------------------
INSERT INTO `dt_student` VALUES (1, '2018001', '123456', '张鲸念', 1, 1, 1, 1, '18500000000');
INSERT INTO `dt_student` VALUES (2, '2018002', '123456', '张彬华', 1, 1, 1, 1, '18500000000');
INSERT INTO `dt_student` VALUES (3, '2018003', '123456', '张瑞政', 1, 1, 1, 1, '18500000000');
INSERT INTO `dt_student` VALUES (4, '2018004', '123456', '张京楚', 1, 1, 2, 1, '18500000000');
INSERT INTO `dt_student` VALUES (5, '2018005', '123456', '陈发语', 1, 1, 2, 1, '18500000000');
INSERT INTO `dt_student` VALUES (6, '2018006', '123456', '陈泊依', 1, 1, 2, 0, '18500000000');
INSERT INTO `dt_student` VALUES (7, '2018007', '123456', '陈泊夕', 1, 5, 3, 0, '18500000000');
INSERT INTO `dt_student` VALUES (8, '2018008', '123456', '陈阿伯', 1, 3, 5, 0, '18500000000');
INSERT INTO `dt_student` VALUES (9, '2018009', '123456', '陈贻范', 1, 2, 6, 0, '18500000000');
INSERT INTO `dt_student` VALUES (10, '2018010', '123456', '陈诚任', 1, 7, 4, 0, '18500000000');

-- ----------------------------
-- Table structure for dt_user
-- ----------------------------
DROP TABLE IF EXISTS `dt_user`;
CREATE TABLE `dt_user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `user_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` int(0) NULL DEFAULT NULL COMMENT '0管理员',
  `remark` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_user
-- ----------------------------
INSERT INTO `dt_user` VALUES (1, 'admin', '123456', 'admin', '11111111111', 0, '');
INSERT INTO `dt_user` VALUES (2, 'yang', '123456', '杨管理员', '11111111111', 0, '');
INSERT INTO `dt_user` VALUES (3, 'wang', '123456', '王管理员', '11111111111', 0, '');

-- ----------------------------
-- Table structure for dt_visitor
-- ----------------------------
DROP TABLE IF EXISTS `dt_visitor`;
CREATE TABLE `dt_visitor`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `visitor` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` int(0) NULL DEFAULT NULL,
  `building_id` int(0) NULL DEFAULT NULL,
  `storey_id` int(0) NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `student_id` int(0) NULL DEFAULT NULL,
  `visit_time` datetime(0) NULL DEFAULT NULL,
  `leave_time` datetime(0) NULL DEFAULT NULL,
  `remark` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_visitor
-- ----------------------------
INSERT INTO `dt_visitor` VALUES (1, '张三', '11111111111', 1, 1, 1, 1, 1, '2022-03-23 00:00:00', '2022-03-24 00:00:00', '');
INSERT INTO `dt_visitor` VALUES (2, '李四', '11111111111', 1, 1, 1, 5, 2, '2022-04-21 00:00:00', '2022-04-22 00:00:00', '');

-- ----------------------------
-- Table structure for dt_waterelectricity
-- ----------------------------
DROP TABLE IF EXISTS `dt_waterelectricity`;
CREATE TABLE `dt_waterelectricity`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `building_id` int(0) NULL DEFAULT NULL,
  `storey_id` int(0) NULL DEFAULT NULL,
  `dormitory_id` int(0) NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `water_rate` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `electric_charge` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` date NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of dt_waterelectricity
-- ----------------------------
INSERT INTO `dt_waterelectricity` VALUES (1, 1, 1, 1, '3月份宿舍水电账单', '30', '500', '2022-04-17');
INSERT INTO `dt_waterelectricity` VALUES (2, 2, 8, 2, '3月份宿舍水电账单', '55.1', '480.3', '2022-04-17');

SET FOREIGN_KEY_CHECKS = 1;
