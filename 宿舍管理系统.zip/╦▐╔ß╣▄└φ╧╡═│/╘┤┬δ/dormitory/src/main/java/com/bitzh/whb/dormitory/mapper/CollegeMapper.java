package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.College;

public interface CollegeMapper {

	public int create(College college);

	public int delete(Integer id);

	public int update(College college);

	public int updateSelective(College college);

	public List<College> query(College college);

	public College detail(Integer id);

	public int count(College college);
}