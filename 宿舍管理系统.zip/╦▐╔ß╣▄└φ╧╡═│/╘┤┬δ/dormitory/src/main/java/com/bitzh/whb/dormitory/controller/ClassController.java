package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.entity.Class;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/classes")
public class ClassController {
    @Autowired
    private ClassService classService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private CollegeService collegeService;


    @PostMapping("create")
    public Result create(@RequestBody Class classes){
        int flag = classService.create(classes);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = classService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Class classes){
        int flag = classService.update(classes);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Class detail(Integer id){
        return classService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  Class classes){
        PageInfo<Class> pageInfo = classService.query(classes);
        pageInfo.getList().forEach(entity->{
            Grade grade = gradeService.detail(entity.getGradeId());
            entity.setGrade(grade);
            College college = collegeService.detail(entity.getCollegeId());
            entity.setCollege(college);
        });
        return Result.ok(pageInfo);
    }
}
