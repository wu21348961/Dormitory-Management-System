package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@RequestMapping("/stu")
public class StuController {

    @Autowired
    private StudentService studentService;
    @Autowired
    private CollegeService collegeService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private PrimaryDormitoryService primaryDormitoryService;
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private DormitoryStudentService dormitoryStudentService;
    @Autowired
    private PrimaryService primaryService;
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private ClassService classService;

    @GetMapping("/info")
    public Result info(HttpServletRequest request){
        Student param = (Student)request.getAttribute("student");
        Student student = studentService.detail(param.getId());
        student.setGrade(gradeService.detail(student.getGradeId()));
        student.setCollege(collegeService.detail(student.getCollegeId()));
        student.setClasses(classService.detail(student.getClassId()));
        return Result.ok(student);
    }

    @GetMapping("/select_dormitory")
    public Result select_dormitory(HttpServletRequest request){
        Student param = (Student)request.getAttribute("student");
        Student student = studentService.detail(param.getId());

        PrimaryDormitory primaryDormitory = new PrimaryDormitory();
        primaryDormitory.setClassId(student.getClassId());
        primaryDormitory.setLimit(1000);
        PageInfo<PrimaryDormitory> pageInfo = primaryDormitoryService.query(primaryDormitory);

        List<Map<String,Object>> list = new ArrayList<>();
        //待选宿舍列表
        List<PrimaryDormitory> primaryDormitories = pageInfo.getList();
        for (PrimaryDormitory sd : primaryDormitories) {
            Map<String,Object> map = new HashMap<>();
            //查询宿舍的基本信息
            Dormitory dormitory = dormitoryService.detail(sd.getDormitoryId());
            map.put("capacity",dormitory.getCapacity());
            map.put("id",dormitory.getId());
            map.put("no",dormitory.getNo());
            map.put("sex",dormitory.getSex());
            Building building = buildingService.detail(dormitory.getBuildingId());
            map.put("Name",building.getName());

            //查询已选择的所有的学生
            DormitoryStudent ds = new DormitoryStudent();
            ds.setDormitoryId(sd.getDormitoryId());
            ds.setLimit(1000);
            PageInfo<DormitoryStudent> dormitoryStudents = dormitoryStudentService.query(ds);
            map.put("selected",dormitoryStudents.getList().size());

            //构造已选择的同学信息
            List<Map<String,Object>> studentMapList = new ArrayList<>();
            List<DormitoryStudent> list1 = dormitoryStudents.getList();
            list1.forEach(ds1->{
                Map<String,Object> studentMap = new HashMap<>();
                Student detail = studentService.detail(ds1.getStudentId());
                studentMap.put("stuNo",detail.getStuNo());
                studentMap.put("name",detail.getName());
                studentMap.put("bedId",ds1.getBedId());
                studentMapList.add(studentMap);
            });
            map.put("studentList",studentMapList);
            list.add(map);
        }
        return Result.ok(list);
    }

    @PostMapping("/select_dormitory_submit")
    public Result select_dormitory_submit(@RequestBody Map<String, String> map, HttpServletRequest request) {
        Student param = (Student) request.getAttribute("student");
        Student student = studentService.detail(param.getId());

        List<Primary> primary = primaryService.queryByClassId(student.getClassId());
        if (primary != null && primary.size() == 0) {
            return Result.fail("操作失败，未找到预选宿舍信息！请联系管理员");
        }
        Primary primaries = primary.get(0);
        if (primaries.getStartTime().getTime() > System.currentTimeMillis() || System.currentTimeMillis() > primaries.getEndTime().getTime()) {
            return Result.fail("操作失败，当前不在预选宿舍时间段内！请联系管理员");
        }
        String bedId = map.get("bedId");
        String dormitoryId = map.get("dormitoryId");
        Dormitory dormitory = new Dormitory();
        dormitory.setId(Integer.parseInt(dormitoryId));
        PageInfo<Dormitory> dormitoryPageInfo = dormitoryService.query(dormitory);
        if (student.getSex() == 0 && dormitoryPageInfo.getList().get(0).getSex() == 1) {
            return Result.fail("操作失败，该宿舍为男生宿舍！请重新选择宿舍");
        } else if (student.getSex() == 1 && dormitoryPageInfo.getList().get(0).getSex() == 0) {
            return Result.fail("操作失败，该宿舍为女生宿舍！请重新选择宿舍");
        }
        int row = dormitoryStudentService.select_dormitory_submit(student.getId(), Integer.parseInt(dormitoryId), Integer.parseInt(bedId));
        if (row > 0) {
            return Result.ok();
        } else {
            return Result.fail();
        }
    }

    @PostMapping("stu_judge_accommodation")
    public Result stu_judge_accommodation(HttpServletRequest request){
        Student student = (Student)request.getAttribute("student");
        DormitoryStudent ds = new DormitoryStudent();
        ds.setStudentId(student.getId());
        PageInfo<DormitoryStudent> pageInfo = dormitoryStudentService.query(ds);
        if(pageInfo.getList() != null && pageInfo.getList().size()>0){
            return Result.ok();
        }else{
            return Result.fail("操作失败，还没有选宿舍");
        }
    }
}
