package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.College;
import com.bitzh.whb.dormitory.mapper.CollegeMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class CollegeService {

    @Autowired
    private CollegeMapper collegeMapper;

    public int create(College college) {
        return collegeMapper.create(college);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                collegeMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return collegeMapper.delete(id);
    }

    public int update(College college) {
        return collegeMapper.update(college);
    }

    public int updateSelective(College college) {
        return collegeMapper.updateSelective(college);
    }

    public PageInfo<College> query(College college) {
        if(college != null && college.getPage() != null){
            PageHelper.startPage(college.getPage(),college.getLimit());
        }
        return new PageInfo<College>(collegeMapper.query(college));
    }

    public College detail(Integer id) {
        return collegeMapper.detail(id);
    }

    public int count(College college) {
        return collegeMapper.count(college);
    }

}
