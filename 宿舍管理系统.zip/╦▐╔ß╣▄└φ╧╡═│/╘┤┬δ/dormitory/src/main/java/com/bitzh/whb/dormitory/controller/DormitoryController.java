package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/dormitory")
public class DormitoryController {
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private StoreyService storeyService;
    @Autowired
    private BedService bedService;
    @Autowired
    private DormitoryStudentService dormitoryStudentService;

    @PostMapping("create")
    public Result create(@RequestBody Dormitory dormitory){
        int flag = dormitoryService.create(dormitory);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = dormitoryService.delete(ids);
        if(flag>0){
            Bed bed = new Bed();
            bed.setDormitoryId(Integer.parseInt(ids));
            PageInfo<Bed> bedPageInfo = bedService.query(bed);
            if (bedPageInfo.getTotal() != 0) {
                for (int i=0;i<bedPageInfo.getTotal();i++) {
                    bedService.delete(bedPageInfo.getList().get(i).getId());
                    DormitoryStudent dormitoryStudent = new DormitoryStudent();
                    dormitoryStudent.setBedId(bedPageInfo.getList().get(i).getId());
                    PageInfo<DormitoryStudent> dormitoryStudentPageInfo = dormitoryStudentService.query(dormitoryStudent);
                    if (dormitoryStudentPageInfo.getTotal() != 0) {
                        dormitoryStudentService.delete(dormitoryStudentPageInfo.getList().get(0).getId());
                    }
                }
            }
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Dormitory dormitory){
        int flag = dormitoryService.update(dormitory);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Dormitory detail(Integer id){
        return dormitoryService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  Dormitory dormitory){
        PageInfo<Dormitory> pageInfo = dormitoryService.query(dormitory);
        pageInfo.getList().forEach(entity-> {
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);
        });
        return Result.ok(pageInfo);
    }

    @PostMapping("init")
    public Result init(@RequestBody  Dormitory dormitory){
        dormitoryService.init(dormitory);
        return Result.ok();
    }

    @GetMapping("/dormitoryBalance")
    public Result dormitoryBalance(HttpServletRequest request){
        Student param = (Student) request.getAttribute("student");
        DormitoryStudent dormitoryStudent = new DormitoryStudent();
        dormitoryStudent.setStudentId(param.getId());
        PageInfo<DormitoryStudent> dormitoryStudentPageInfo = dormitoryStudentService.query(dormitoryStudent);
        if (dormitoryStudentPageInfo.getList().size() == 0){
            return Result.ok(-1);
        }else {
            int dormitoryId = dormitoryStudentPageInfo.getList().get(0).getDormitoryId();
            // 将数据处理后四舍五入保留两位小数
            Double dormitoryBalance = dormitoryService.queryDormitoryBalance(dormitoryId);
            BigDecimal bd1 = new BigDecimal(dormitoryBalance);
            dormitoryBalance = bd1.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            return Result.ok(dormitoryBalance);
        }
    }
}
