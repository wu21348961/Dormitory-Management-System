package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/waterElectricity")
public class WaterElectricityController {
    @Autowired
    private WaterElectricityService waterElectricityService;
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private StoreyService storeyService;
    @Autowired
    private DormitoryService dormitoryService;

    @PostMapping("create")
    public Result create(@RequestBody WaterElectricity waterElectricity){
        int flag = waterElectricityService.create(waterElectricity);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = waterElectricityService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody WaterElectricity waterElectricity){
        int flag = waterElectricityService.update(waterElectricity);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public WaterElectricity detail(Integer id){
        return waterElectricityService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  WaterElectricity waterElectricity){
        PageInfo<WaterElectricity> pageInfo = waterElectricityService.query(waterElectricity);
        pageInfo.getList().forEach(entity->{
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);

            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);
        });
        return Result.ok(pageInfo);
    }


}
