package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.*;
import java.util.*;

@RestController
@RequestMapping("/repair")
public class RepairController {
    @Autowired
    private RepairService repairService;
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private StoreyService storeyService;
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private DormitoryStudentService dormitoryStudentService;

    @PostMapping("create")
    public Result create(@RequestBody Repair repair){
        int flag = repairService.create(repair);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = repairService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Repair repair){
        int flag = repairService.updateSelective(repair);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Repair detail(Integer id){
        return repairService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  Repair repair){
        PageInfo<Repair> pageInfo = repairService.query(repair);
        pageInfo.getList().forEach(entity->{
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);

            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }

    @PostMapping("stu_repairData")
    public Result stu_repairData(@RequestBody Repair repair, HttpServletRequest request){
        Student student = (Student)request.getAttribute("student");
        DormitoryStudent ds = new DormitoryStudent();
        ds.setStudentId(student.getId());
        PageInfo<DormitoryStudent> pageInfo = dormitoryStudentService.query(ds);
        DormitoryStudent dormitoryStudent = pageInfo.getList().get(0);
        Dormitory detail = dormitoryService.detail(dormitoryStudent.getDormitoryId());
        repair.setBuildingId(detail.getBuildingId());
        repair.setStoreyId(detail.getStoreyId());
        repair.setDormitoryId(dormitoryStudent.getDormitoryId());
        repair.setStudentId(student.getId());
        return Result.ok(repair);
    }

    @PostMapping("stu_repairList")
    public Map<String,Object> query(@RequestBody Repair repair, HttpServletRequest request){
        Student param = (Student)request.getAttribute("student");
        repair.setStudentId(param.getId());
        PageInfo<Repair> pageInfo = repairService.query(repair);
        pageInfo.getList().forEach(entity->{
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);

            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }
}
