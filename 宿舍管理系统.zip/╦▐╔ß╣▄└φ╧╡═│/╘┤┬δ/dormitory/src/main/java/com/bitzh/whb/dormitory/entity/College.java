package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;


public class College extends Entity {

	private Integer id;

	private String college;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
}