package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;


public class Class extends Entity {

	private Integer id;

	private Integer gradeId;

	private Integer collegeId;

	private String professionalclass;

	private Grade grade;

	private College college;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public Integer getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(Integer collegeId) {
		this.collegeId = collegeId;
	}

	public String getProfessionalclass() {
		return professionalclass;
	}
	public void setProfessionalclass(String professionalclass) {
		this.professionalclass = professionalclass;
	}

	public Grade getGrade() {
		return grade;
	}
	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}
}