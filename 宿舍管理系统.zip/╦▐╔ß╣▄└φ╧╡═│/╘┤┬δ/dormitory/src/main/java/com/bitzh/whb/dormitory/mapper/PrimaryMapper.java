package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.Primary;

public interface PrimaryMapper {

	public int create(Primary primary);

	public int delete(Integer id);

	public int update(Primary primary);

	public int updateSelective(Primary primary);

	public List<Primary> query(Primary primary);

	public List<Primary> queryByClassId(Integer classId);

	public Primary detail(Integer id);

	public int count(Primary primary);

	public List<Integer> classes(Integer id);
}