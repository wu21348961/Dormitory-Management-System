package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;
import org.hibernate.validator.constraints.Length;

import java.util.Date;
import java.util.List;


public class Primary extends Entity {

	private Integer id;

	@Length(max = 100)
	private String name;

	private Date startTime;

	private Date endTime;

	private Integer gradeId;

	private Integer collegeId;

	@Length(max = 100)
	private String remark;

	private College college;

	private Grade grade;

	private List<Class> classes;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Integer getGradeId() {
		return gradeId;
	}
	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public Integer getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(Integer collegeId) {
		this.collegeId = collegeId;
	}

	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Grade getGrade() {
		return grade;
	}
	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}

	public List<Class> getClasses() {
		return classes;
	}
	public void setClasses(List<Class> classes) {
		this.classes = classes;
	}
}