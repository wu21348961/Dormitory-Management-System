package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/primaryDormitory")
public class PrimaryDormitoryController {
    @Autowired
    private PrimaryDormitoryService primaryDormitoryService;

    @PostMapping("create")
    public Result create(@RequestBody Map<String,String> map){
        String classId = map.get("classId");
        String dormitoryId = map.get("dormitoryId");
        String buildingId = map.get("buildingId");
        int flag = primaryDormitoryService.create(classId,dormitoryId,buildingId);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = primaryDormitoryService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody PrimaryDormitory primaryDormitory){
        int flag = primaryDormitoryService.update(primaryDormitory);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public PrimaryDormitory detail(Integer id){
        return primaryDormitoryService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody PrimaryDormitory primaryDormitory){
        PageInfo<PrimaryDormitory> pageInfo = primaryDormitoryService.query(primaryDormitory);
        return Result.ok(pageInfo);
    }

}
