package com.bitzh.whb.dormitory.mapper;

import com.bitzh.whb.dormitory.entity.Menu;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MenuMapper {

	public List<Menu> query(Integer userId);

	public List<Menu> queryByType();

	public List<Menu> list();

	public List<Integer> queryCheckMenuId();

}