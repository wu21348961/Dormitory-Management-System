package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;
import org.hibernate.validator.constraints.Length;



public class Grade extends Entity {

	private Integer id;

	@Length(max = 100)
	private String grade;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
}