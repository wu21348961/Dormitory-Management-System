package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.entity.Class;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/primary")
public class PrimaryController {
    @Autowired
    private PrimaryService primaryService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private CollegeService collegeService;
    @Autowired
    private ClassService classService;

    @PostMapping("create")
    public Result create(@RequestBody Primary primary){
        int flag = primaryService.create(primary);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = primaryService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Primary primary){
        int flag = primaryService.update(primary);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Primary detail(Integer id){
        return primaryService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody Primary primary){
        PageInfo<Primary> pageInfo = primaryService.query(primary);
        pageInfo.getList().forEach(entity->{
            //年级
            Grade grade = gradeService.detail(entity.getGradeId());
            entity.setGrade(grade);
            //学院
            College college = collegeService.detail(entity.getCollegeId());
            entity.setCollege(college);
        });
        pageInfo.getList().forEach(item->{
            List<Class> classes = classService.queryClassByPrimaryId(item.getId());
            item.setClasses(classes);
        });
        return Result.ok(pageInfo);
    }

    @GetMapping("classes")
    public Result classes(Integer id) {
        List<Integer> primaryList = primaryService.classes(id);
        return Result.ok(primaryList);
    }
}
