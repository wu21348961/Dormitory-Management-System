package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.PrimaryDormitory;
import com.bitzh.whb.dormitory.mapper.PrimaryDormitoryMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class PrimaryDormitoryService {

    @Autowired
    private PrimaryDormitoryMapper primaryDormitoryMapper;

    public int create(String classId,String dormitoryId,String buildingId) {
        String[] arr = dormitoryId.split(",");
        primaryDormitoryMapper.deleteByClassId(Integer.parseInt(classId),Integer.parseInt(buildingId));
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                PrimaryDormitory primaryDormitory = new PrimaryDormitory();
                primaryDormitory.setClassId(Integer.parseInt(classId));
                primaryDormitory.setBuildingId(Integer.parseInt(buildingId));
                primaryDormitory.setDormitoryId(Integer.parseInt(s));
                primaryDormitoryMapper.create(primaryDormitory);
            }
        }
        return 1;
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                primaryDormitoryMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return primaryDormitoryMapper.delete(id);
    }

    public int update(PrimaryDormitory primaryDormitory) {
        return primaryDormitoryMapper.update(primaryDormitory);
    }

    public int updateSelective(PrimaryDormitory primaryDormitory) {
        return primaryDormitoryMapper.updateSelective(primaryDormitory);
    }

    public PageInfo<PrimaryDormitory> query(PrimaryDormitory primaryDormitory) {
        if(primaryDormitory != null && primaryDormitory.getPage() != null){
            PageHelper.startPage(primaryDormitory.getPage(), primaryDormitory.getLimit());
        }
        return new PageInfo<PrimaryDormitory>(primaryDormitoryMapper.query(primaryDormitory));
    }

    public PrimaryDormitory detail(Integer id) {
        return primaryDormitoryMapper.detail(id);
    }

    public int count(PrimaryDormitory primaryDormitory) {
        return primaryDormitoryMapper.count(primaryDormitory);
    }
}
