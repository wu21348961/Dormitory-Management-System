package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.Building;
import com.bitzh.whb.dormitory.entity.Dormitory;
import com.bitzh.whb.dormitory.mapper.BedMapper;
import com.bitzh.whb.dormitory.mapper.BuildingMapper;
import com.bitzh.whb.dormitory.mapper.DormitoryMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class DormitoryService {

    @Autowired
    private DormitoryMapper dormitoryMapper;
    @Autowired
    private BuildingMapper buildingMapper;
    @Autowired
    private BedMapper bedMapper;

    public int create(Dormitory dormitory) {
        return dormitoryMapper.create(dormitory);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                dormitoryMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return dormitoryMapper.delete(id);
    }

    public int update(Dormitory dormitory) {
        return dormitoryMapper.update(dormitory);
    }

    public int updateSelective(Dormitory dormitory) {
        return dormitoryMapper.updateSelective(dormitory);
    }

    public PageInfo<Dormitory> query(Dormitory dormitory) {
        if(dormitory != null && dormitory.getPage() != null){
            PageHelper.startPage(dormitory.getPage(),dormitory.getLimit());
        }
        return new PageInfo<Dormitory>(dormitoryMapper.query(dormitory));
    }

    public Dormitory detail(Integer id) {
        return dormitoryMapper.detail(id);
    }

    public int count(Dormitory dormitory) {
        return dormitoryMapper.count(dormitory);
    }

    @Transactional
    public void init(Dormitory dormitory){
        Building building = buildingMapper.detail(dormitory.getBuildingId());

        //删除已有床位（先查询出来，然后批量删除）
        List<Dormitory> dormitoryList = dormitoryMapper.query(dormitory);
        dormitoryList.forEach(item->{
            bedMapper.deleteByDormitoryId(item.getId());
        });
        //删除以有的数据(删除已有宿舍)
        dormitoryMapper.deleteByBuildingIdAndStoryId(dormitory.getBuildingId(),dormitory.getStoreyId());
    }

    public double queryDormitoryBalance(Integer dormitoryId){
        return dormitoryMapper.queryDormitoryBalance(dormitoryId);
    }

    public int changeBalance(Double newBalance, Integer dormitoryId){
        return dormitoryMapper.changeBalance(newBalance, dormitoryId);
    }
}
