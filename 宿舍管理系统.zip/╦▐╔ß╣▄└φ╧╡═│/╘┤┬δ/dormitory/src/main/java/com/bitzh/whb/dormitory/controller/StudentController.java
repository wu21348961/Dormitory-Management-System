package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.entity.Class;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private CollegeService collegeService;
    @Autowired
    private ClassService classService;

    @PostMapping("create")
    public Result create(@RequestBody Student student){
        String rule1 = "^[a-zA-Z0-9]+$";
        String rule2 = "^[0-9]+$";
        if (!student.getStuNo().matches(rule1)) {
            return Result.fail("学号不能输入中文和特殊符号！");
        } else if (!student.getPhone().matches(rule2)) {
            return Result.fail("手机号只能为数字!");
        } else if (student.getPhone().length() != 11) {
            return Result.fail("手机号为11位！请重新输入");
        } else {
            int flag = studentService.create(student);
            if(flag>0){
                return Result.ok();
            }else{
                return Result.fail("数据类型错误！请重新输入");
            }
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = studentService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Student student){
        String rule1 = "^[a-zA-Z0-9]+$";
        String rule2 = "^[0-9]+$";
        if (!student.getStuNo().matches(rule1)) {
            return Result.fail("学号不能输入中文和特殊符号！");
        } else if (!student.getPhone().matches(rule2)) {
            return Result.fail("手机号只能为数字!");
        } else if (student.getPhone().length() != 11) {
            return Result.fail("手机号为11位！请重新输入");
        } else {
            int flag = studentService.updateSelective(student);
            if(flag>0){
                return Result.ok();
            }else{
                return Result.fail("数据类型错误！请重新输入");
            }
        }
    }

    @GetMapping("detail")
    public Student detail(Integer id){
        return studentService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody Student student){
        PageInfo<Student> pageInfo = studentService.query(student);
        pageInfo.getList().forEach(entity->{
            //年级
            Grade grade = gradeService.detail(entity.getGradeId());
            entity.setGrade(grade);
            //学院
            College college = collegeService.detail(entity.getCollegeId());
            entity.setCollege(college);
            //班级
            Class classes = classService.detail(entity.getClassId());
            entity.setClasses(classes);
        });
        return Result.ok(pageInfo);
    }

}
