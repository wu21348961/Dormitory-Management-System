package com.bitzh.whb.dormitory.mapper;

import com.bitzh.whb.dormitory.entity.Bill;

import java.util.*;


public interface BillMapper {

	public int create(Bill bill);

	public int delete(Integer id);

	public int update(Bill bill);

	public int updateSelective(Bill bill);

	public List<Bill> query(Bill bill);

	public Bill detail(Integer id);

	public int count(Bill bill);

	public List<Bill> queryDormitoryExpenditure(Integer studentId);

	public Date queryMaxDate(Integer dormitoryId);

	public Double queryMonthlyExpenditureByClassification(Integer dormitoryId, Integer year, Integer month, Integer classification);

}