package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;


@RestController
@RequestMapping("/bill")
public class BillController {
    @Autowired
    private BillService billService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private DormitoryStudentService dormitoryStudentService;


    // 创建新的房间账目，并修改房间余额
    @PostMapping("create")
    public Result create(@RequestBody Bill bill, HttpServletRequest request){
        Student param = (Student) request.getAttribute("student");
        int studentId = param.getId();
        DormitoryStudent dormitoryStudent = dormitoryStudentService.detail(studentId);
        int dormitoryId = dormitoryStudent.getDormitoryId();
        bill.setDormitoryId(dormitoryId);
        bill.setStudentId(studentId);
        bill.setSpendTime(new Date());
        double newBalance = dormitoryService.queryDormitoryBalance(dormitoryId);   //查询当前房间余额
        if(bill.getType()==0){
            newBalance = newBalance - bill.getMoney();
            bill.setBalance(newBalance);
        }else {
            newBalance = newBalance + bill.getMoney();
            bill.setBalance(newBalance);
        }
        dormitoryService.changeBalance(newBalance, dormitoryId);
        int flag = billService.create(bill);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = billService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Bill bill){
        int flag = billService.update(bill);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Bill detail(Integer id){
        return billService.detail(id);
    }

    @PostMapping("query")
    public Map<String, Object> queryDormitory(@RequestBody Bill bill ,HttpServletRequest request){
        Student param = (Student) request.getAttribute("student");
        DormitoryStudent dormitoryStudent = new DormitoryStudent();
        dormitoryStudent.setStudentId(param.getId());
        PageInfo<DormitoryStudent> dormitoryStudentPageInfo = dormitoryStudentService.query(dormitoryStudent);
        if (dormitoryStudentPageInfo.getList().size() == 0){
            return Result.ok(dormitoryStudentPageInfo);
        }else {
            bill.setDormitoryId(dormitoryStudentPageInfo.getList().get(0).getDormitoryId());
            PageInfo<Bill> pageInfo = billService.query(bill);
            pageInfo.getList().forEach(entity->{
                Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
                entity.setDormitory(dormitory);

                Student student = studentService.detail(entity.getStudentId());
                entity.setStudent(student);
            });
            return Result.ok(pageInfo);
        }
    }


    // 查询学生所在房间当月所有支出
    // 旭日图中使用该数据
    @PostMapping("queryDormitoryExpenditure")
    public Map<String, Object> queryDormitoryExpenditure(HttpServletRequest request){
        Student param = (Student) request.getAttribute("student");
        int studentId = param.getId();
        PageInfo<Bill> pageInfo = billService.queryDormitoryExpenditure(studentId);
        pageInfo.getList().forEach(entity->{
            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }


    // 查询本房间的近几个月的消费数据
    // 堆叠图中使用该数据
    @GetMapping("/queryDormitoryEachMonthInfo")
    public Result queryDormitoryEachMonthInfo(HttpServletRequest request) {
        Student param = (Student) request.getAttribute("student");
        DormitoryStudent dormitoryStudent = new DormitoryStudent();
        dormitoryStudent.setStudentId(param.getId());
        PageInfo<DormitoryStudent> dormitoryStudentPageInfo = dormitoryStudentService.query(dormitoryStudent);
        if (dormitoryStudentPageInfo.getList().size() == 0) {
            return Result.ok(-1);
        } else {
            int dormitoryId = dormitoryStudentPageInfo.getList().get(0).getDormitoryId();
            Date latestDate = billService.queryMaxDate(dormitoryId);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dateFormatted = sdf.format(latestDate);
            int latestYear = Integer.parseInt(dateFormatted.substring(0, 4));
            int latestMonth = Integer.parseInt(dateFormatted.substring(5, 7));
            List<Double> waterList = new ArrayList<>();                       // 水电
            List<Double> foodList = new ArrayList<>();                        // 餐饮
            List<Double> bookList = new ArrayList<>();                        // 图书
            List<Double> entertainmentList = new ArrayList<>();               // 娱乐
            List<Integer> monthList = new ArrayList<>();                      // 月

            // 近三个月的支出数据
            for (int i = latestMonth; i > latestMonth - 4; i--) {

                Double water = billService.queryMonthlyExpenditureByClassification(dormitoryId, latestYear, i, 0);
                waterList.add(water);

                Double food = billService.queryMonthlyExpenditureByClassification(dormitoryId, latestYear, i, 1);
                foodList.add(food);

                Double book = billService.queryMonthlyExpenditureByClassification(dormitoryId, latestYear, i, 2);
                bookList.add(book);

                Double entertainment = billService.queryMonthlyExpenditureByClassification(dormitoryId, latestYear, i, 3);
                entertainmentList.add(entertainment);

                monthList.add(i);
            }
            List<Object> finalList = new ArrayList<>();
            finalList.add(waterList);
            finalList.add(foodList);
            finalList.add(bookList);
            finalList.add(entertainmentList);
            finalList.add(monthList);
            return Result.ok(finalList);
        }
    }
}
