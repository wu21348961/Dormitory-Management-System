package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.mapper.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class WaterElectricityService {

    @Autowired
    private WaterElectricityMapper waterElectricityMapper;

    public int create(WaterElectricity waterElectricity) {
        return waterElectricityMapper.create(waterElectricity);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                waterElectricityMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return waterElectricityMapper.delete(id);
    }

    public int update(WaterElectricity waterElectricity) {
        return waterElectricityMapper.update(waterElectricity);
    }

    public int updateSelective(WaterElectricity waterElectricity) {
        return waterElectricityMapper.updateSelective(waterElectricity);
    }

    public PageInfo<WaterElectricity> query(WaterElectricity waterElectricity) {
        if(waterElectricity != null && waterElectricity.getPage() != null){
            PageHelper.startPage(waterElectricity.getPage(),waterElectricity.getLimit());
        }
        return new PageInfo<WaterElectricity>(waterElectricityMapper.query(waterElectricity));
    }

    public WaterElectricity detail(Integer id) {
        return waterElectricityMapper.detail(id);
    }

    public int count(WaterElectricity waterElectricity) {
        return waterElectricityMapper.count(waterElectricity);
    }
}
