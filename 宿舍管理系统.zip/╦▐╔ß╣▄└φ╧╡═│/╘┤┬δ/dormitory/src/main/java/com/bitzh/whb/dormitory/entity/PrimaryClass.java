package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;


public class PrimaryClass extends Entity {

	private Integer id;

	private Integer primaryId;

	private Integer classId;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPrimaryId() {
		return primaryId;
	}
	public void setPrimaryId(Integer primaryId) {
		this.primaryId = primaryId;
	}

	public Integer getClassId() {
		return classId;
	}
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
}