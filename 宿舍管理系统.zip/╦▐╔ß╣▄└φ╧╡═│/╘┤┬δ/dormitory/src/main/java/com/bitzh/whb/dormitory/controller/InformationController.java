package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/information")
public class InformationController {
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private BedService bedService;
    @Autowired
    private DormitoryStudentService dormitoryStudentService;
    @Autowired
    private NoticeService noticeService;

    @GetMapping("/building")
    public Result building(){
        Building building = new Building();
        building.setLimit(1000);
        PageInfo<Building> pageInfo = buildingService.query(building);
        List<Map<String,Object>> list = new ArrayList<>();
        DecimalFormat df   = new DecimalFormat("######0.00");
        pageInfo.getList().forEach(entity->{
            Map<String,Object> map = new HashMap<>();
            Dormitory dormitory = new Dormitory();
            dormitory.setBuildingId(entity.getId());
            dormitory.setLimit(1000000);
            PageInfo<Dormitory> dormitoryPageInfo = dormitoryService.query(dormitory);
            Bed bed = new Bed();
            bed.setBuildingId(entity.getId());
            bed.setLimit(1000000);
            PageInfo<Bed> bedPageInfo = bedService.query(bed);
            int dormitoryAll = dormitoryPageInfo.getList().size();
            int bedAll = bedPageInfo.getList().size();
            map.put("name",entity.getName());
            map.put("dormitoryAll",dormitoryAll);
            map.put("bedAll",bedAll);
            int used = dormitoryStudentService.countByBuildingId(entity.getId());
            map.put("used",used);
            int unused = bedAll-used;
            map.put("unused",unused);
            if(bedAll == 0){
                map.put("percent",0);
            }else{
                map.put("percent",df.format((float)used*100/bedAll));
            }

            list.add(map);
        });
        return Result.ok(list);
    }

    @GetMapping("/notice")
    public Result notice(){
        Notice notice = new Notice();
        notice.setLimit(5);
        PageInfo<Notice> pageInfo = noticeService.query(notice);
        return Result.ok(pageInfo.getList());
    }


}
