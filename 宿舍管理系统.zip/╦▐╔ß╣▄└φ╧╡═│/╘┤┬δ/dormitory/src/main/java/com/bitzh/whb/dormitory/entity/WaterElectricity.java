package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;

import java.util.Date;


public class WaterElectricity extends Entity {

	private Integer id;

	private Integer buildingId;

	private Integer storeyId;

	private Integer dormitoryId;

	private String name;

	private String waterRate;

	private String electricCharge;

	private Date createTime;

	private Building building;

	private Storey storey;

	private Dormitory dormitory;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(Integer buildingId) {
		this.buildingId = buildingId;
	}

	public Integer getStoreyId() {
		return storeyId;
	}
	public void setStoreyId(Integer storeyId) {
		this.storeyId = storeyId;
	}

	public Integer getDormitoryId() {
		return dormitoryId;
	}
	public void setDormitoryId(Integer dormitoryId) {
		this.dormitoryId = dormitoryId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getWaterRate() {
		return waterRate;
	}
	public void setWaterRate(String waterRate) {
		this.waterRate = waterRate;
	}

	public String getElectricCharge() {
		return electricCharge;
	}
	public void setElectricCharge(String electricCharge) {
		this.electricCharge = electricCharge;
	}

	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Building getBuilding() {
		return building;
	}
	public void setBuilding(Building building) {
		this.building = building;
	}

	public Storey getStorey() {
		return storey;
	}
	public void setStorey(Storey storey) {
		this.storey = storey;
	}

	public Dormitory getDormitory() {
		return dormitory;
	}
	public void setDormitory(Dormitory dormitory) {
		this.dormitory = dormitory;
	}
}