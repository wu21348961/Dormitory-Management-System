package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;
import org.hibernate.validator.constraints.Length;



public class Dormitory extends Entity {

	private Integer id;

	private Integer buildingId;

	private Integer storeyId;

	@Length(max = 50)
	private String no;

	private Integer sex;

	private Integer capacity;

	private Double balance;

	private Building building;

	private Storey storey;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(Integer buildingId) {
		this.buildingId = buildingId;
	}

	public Integer getStoreyId() {
		return storeyId;
	}
	public void setStoreyId(Integer storeyId) {
		this.storeyId = storeyId;
	}

	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}

	public Integer getSex() {
		return sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public Integer getCapacity() {
		return capacity;
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Building getBuilding() {
		return building;
	}
	public void setBuilding(Building building) {
		this.building = building;
	}

	public Storey getStorey() {
		return storey;
	}
	public void setStorey(Storey storey) {
		this.storey = storey;
	}
}