package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.PrimaryClass;

public interface PrimaryClassMapper {

	public int create(PrimaryClass primaryClass);

	public int delete(Integer id);

	public int deleteByPrimaryId(Integer primaryId);

	public int update(PrimaryClass primaryClass);

	public int updateSelective(PrimaryClass primaryClass);

	public List<PrimaryClass> query(PrimaryClass primaryClass);

	public PrimaryClass detail(Integer id);

	public int count(PrimaryClass primaryClass);

}