package com.bitzh.whb.dormitory.mapper;

import com.bitzh.whb.dormitory.entity.WaterElectricity;

import java.util.List;

public interface WaterElectricityMapper {

	public int create(WaterElectricity waterElectricity);

	public int delete(Integer id);

	public int update(WaterElectricity waterElectricity);

	public int updateSelective(WaterElectricity waterElectricity);

	public List<WaterElectricity> query(WaterElectricity waterElectricity);

	public WaterElectricity detail(Integer id);

	public int count(WaterElectricity waterElectricity);

}