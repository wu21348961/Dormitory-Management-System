package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;


public class PrimaryDormitory extends Entity {

	private Integer id;

	private Integer buildingId;

	private Integer dormitoryId;

	private Integer classId;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(Integer buildingId) {
		this.buildingId = buildingId;
	}

	public Integer getDormitoryId() {
		return dormitoryId;
	}
	public void setDormitoryId(Integer dormitoryId) {
		this.dormitoryId = dormitoryId;
	}

	public Integer getClassId() {
		return classId;
	}
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
}