package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.Class;

public interface ClassMapper {

	public int create(Class classes);

	public int delete(Integer id);

	public int update(Class classes);

	public int updateSelective(Class classes);

	public List<Class> query(Class classes);

	public Class detail(Integer id);

	public int count(Class classes);

	public List<Class> queryClassByPrimaryId(Integer primaryId);
}