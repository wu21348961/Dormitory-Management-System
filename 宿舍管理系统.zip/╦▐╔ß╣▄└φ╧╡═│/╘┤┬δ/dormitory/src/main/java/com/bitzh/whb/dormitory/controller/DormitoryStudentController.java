package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/dormitoryStudent")
public class DormitoryStudentController {
    @Autowired
    private DormitoryStudentService dormitoryStudentService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private BedService bedService;
    @Autowired
    private DormitoryService dormitoryService;

    
    @PostMapping("create")
    public Result create(@RequestBody DormitoryStudent dormitoryStudent){
        int flag = dormitoryStudentService.create(dormitoryStudent);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = dormitoryStudentService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody DormitoryStudent dormitoryStudent){
        int flag = dormitoryStudentService.update(dormitoryStudent);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public DormitoryStudent detail(Integer id){
        return dormitoryStudentService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  DormitoryStudent dormitoryStudent){
        PageInfo<DormitoryStudent> pageInfo = dormitoryStudentService.query(dormitoryStudent);
        pageInfo.getList().forEach(entity->{
            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }

    @PostMapping("stu_dormitoryStudent")
    public Map<String,Object> stu_dormitoryStudent(@RequestBody DormitoryStudent dormitoryStudent, HttpServletRequest request){
        Student student = (Student)request.getAttribute("student");
        dormitoryStudent.setStudentId(student.getId());
        PageInfo<DormitoryStudent> pageInfo = dormitoryStudentService.query(dormitoryStudent);
        pageInfo.getList().forEach(entity->{
            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Bed bed = bedService.detail(entity.getBedId());
            entity.setBed(bed);

            Student detail1 = studentService.detail(entity.getStudentId());
            entity.setStudent(detail1);
        });
        return Result.ok(pageInfo);
    }

    @PostMapping("stu_dormitoryInformation")
    public Map<String,Object> stu_dormitoryInformation(@RequestBody DormitoryStudent dormitoryStudent){
        PageInfo<DormitoryStudent> pageInfo = dormitoryStudentService.query(dormitoryStudent);
        pageInfo.getList().forEach(entity->{
            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Bed bed = bedService.detail(entity.getBedId());
            entity.setBed(bed);

            Student detail1 = studentService.detail(entity.getStudentId());
            entity.setStudent(detail1);
        });
        return Result.ok(pageInfo);
    }
}
