package com.bitzh.whb.dormitory.entity;

import com.bitzh.whb.dormitory.utils.Entity;
import org.hibernate.validator.constraints.Length;

import java.util.Date;


public class Bill extends Entity{

	private Integer id;

	private Integer dormitoryId;

	private Integer studentId;

	private Integer type;

	private Integer classification;

	private Double money;

	private String spendContent;

	private Date spendTime;

	private Double balance;

	private Dormitory dormitory;

	private Student student;


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDormitoryId() {
		return dormitoryId;
	}
	public void setDormitoryId(Integer dormitoryId) {
		this.dormitoryId = dormitoryId;
	}

	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getClassification() {
		return classification;
	}
	public void setClassification(Integer classification) {
		this.classification = classification;
	}

	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}

	public String getSpendContent() {
		return spendContent;
	}
	public void setSpendContent(String spendContent) {
		this.spendContent = spendContent;
	}

	public Date getSpendTime() {
		return spendTime;
	}
	public void setSpendTime(Date spendTime) {
		this.spendTime = spendTime;
	}

	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Dormitory getDormitory() {
		return dormitory;
	}
	public void setDormitory(Dormitory dormitory) {
		this.dormitory = dormitory;
	}

	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
}