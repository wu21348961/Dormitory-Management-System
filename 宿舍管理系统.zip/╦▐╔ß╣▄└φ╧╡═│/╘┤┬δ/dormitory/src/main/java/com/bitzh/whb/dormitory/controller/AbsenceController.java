package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/absence")
public class AbsenceController {
    @Autowired
    private AbsenceService absenceService;
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private StoreyService storeyService;
    @Autowired
    private DormitoryService dormitoryService;
    @Autowired
    private StudentService studentService;

    @PostMapping("create")
    public Result create(@RequestBody Absence absence){
        int flag = absenceService.create(absence);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = absenceService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody Absence absence){
        int flag = absenceService.update(absence);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public Absence detail(Integer id){
        return absenceService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody  Absence absence){
        PageInfo<Absence> pageInfo = absenceService.query(absence);
        pageInfo.getList().forEach(entity->{
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);

            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }

    @PostMapping("/stu_absenceList")
    public Map<String,Object> query(@RequestBody Absence absence, HttpServletRequest request){
        Student param = (Student)request.getAttribute("student");
        absence.setStudentId(param.getId());
        PageInfo<Absence> pageInfo = absenceService.query(absence);
        pageInfo.getList().forEach(entity->{
            Building building = buildingService.detail(entity.getBuildingId());
            entity.setBuilding(building);

            Storey storey = storeyService.detail(entity.getStoreyId());
            entity.setStorey(storey);

            Dormitory dormitory = dormitoryService.detail(entity.getDormitoryId());
            entity.setDormitory(dormitory);

            Student student = studentService.detail(entity.getStudentId());
            entity.setStudent(student);
        });
        return Result.ok(pageInfo);
    }
}
