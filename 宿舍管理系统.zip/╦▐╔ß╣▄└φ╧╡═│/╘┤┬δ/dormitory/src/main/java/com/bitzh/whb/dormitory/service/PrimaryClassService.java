package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.PrimaryClass;
import com.bitzh.whb.dormitory.mapper.PrimaryClassMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class PrimaryClassService {

    @Autowired
    private PrimaryClassMapper primaryClassMapper;

    public int create(PrimaryClass primaryClass) {
        return primaryClassMapper.create(primaryClass);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                primaryClassMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return primaryClassMapper.delete(id);
    }

    public int update(PrimaryClass primaryClass) {
        return primaryClassMapper.update(primaryClass);
    }

    public int updateSelective(PrimaryClass primaryClass) {
        return primaryClassMapper.updateSelective(primaryClass);
    }

    public PageInfo<PrimaryClass> query(PrimaryClass primaryClass) {
        if(primaryClass != null && primaryClass.getPage() != null){
            PageHelper.startPage(primaryClass.getPage(), primaryClass.getLimit());
        }
        return new PageInfo<PrimaryClass>(primaryClassMapper.query(primaryClass));
    }

    public PrimaryClass detail(Integer id) {
        return primaryClassMapper.detail(id);
    }

    public int count(PrimaryClass primaryClass) {
        return primaryClassMapper.count(primaryClass);
    }
}
