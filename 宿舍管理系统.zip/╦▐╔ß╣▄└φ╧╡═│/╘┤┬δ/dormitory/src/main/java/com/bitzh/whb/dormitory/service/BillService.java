package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.mapper.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;


@Service
public class BillService {

    @Autowired
    private BillMapper billMapper;

    public int create(Bill bill) {
        return billMapper.create(bill);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                billMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return billMapper.delete(id);
    }

    public int update(Bill bill) {
        return billMapper.update(bill);
    }

    public int updateSelective(Bill bill) {
        return billMapper.updateSelective(bill);
    }

    public PageInfo<Bill> query(Bill bill) {
        if(bill != null && bill.getPage() != null){
            PageHelper.startPage(bill.getPage(),bill.getLimit());
        }
        return new PageInfo<Bill>(billMapper.query(bill));
    }

    public Bill detail(Integer id) {
        return billMapper.detail(id);
    }

    public int count(Bill bill) {
        return billMapper.count(bill);
    }


    public PageInfo<Bill> queryDormitoryExpenditure(Integer studentId){
        return new PageInfo<Bill>(billMapper.queryDormitoryExpenditure(studentId));
    }

    public Date queryMaxDate(Integer dormitoryId){
        return billMapper.queryMaxDate(dormitoryId);
    }

    public Double queryMonthlyExpenditureByClassification(Integer dormitoryId, Integer year, Integer month, Integer classification){
        return billMapper.queryMonthlyExpenditureByClassification(dormitoryId, year, month, classification);
    }
}
