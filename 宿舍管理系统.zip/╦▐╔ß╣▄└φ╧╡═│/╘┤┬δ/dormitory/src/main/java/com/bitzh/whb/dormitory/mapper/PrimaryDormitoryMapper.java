package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.PrimaryDormitory;

public interface PrimaryDormitoryMapper {

	public int create(PrimaryDormitory primaryDormitory);

	public int delete(Integer id);

	public int deleteByClassId(Integer classId,Integer buildingId);

	public int update(PrimaryDormitory primaryDormitory);

	public int updateSelective(PrimaryDormitory primaryDormitory);

	public List<PrimaryDormitory> query(PrimaryDormitory primaryDormitory);

	public PrimaryDormitory detail(Integer id);

	public int count(PrimaryDormitory primaryDormitory);

}