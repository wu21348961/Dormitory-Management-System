package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/primaryClass")
public class PrimaryClassController {
    @Autowired
    private PrimaryClassService primaryClassService;

    @PostMapping("create")
    public Result create(@RequestBody PrimaryClass primaryClass){
        int flag = primaryClassService.create(primaryClass);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = primaryClassService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody PrimaryClass primaryClass){
        int flag = primaryClassService.update(primaryClass);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @GetMapping("detail")
    public PrimaryClass detail(Integer id){
        return primaryClassService.detail(id);
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody PrimaryClass primaryClass){
        PageInfo<PrimaryClass> pageInfo = primaryClassService.query(primaryClass);
        return Result.ok(pageInfo);
    }

}
