package com.bitzh.whb.dormitory.mapper;

import java.util.List;

import com.bitzh.whb.dormitory.entity.Absence;

public interface AbsenceMapper {

	public int create(Absence absence);

	public int delete(Integer id);

	public int update(Absence absence);

	public int updateSelective(Absence absence);

	public List<Absence> query(Absence absence);

	public Absence detail(Integer id);

	public int count(Absence absence);

}