package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.Primary;
import com.bitzh.whb.dormitory.entity.PrimaryClass;
import com.bitzh.whb.dormitory.mapper.PrimaryClassMapper;
import com.bitzh.whb.dormitory.mapper.PrimaryMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class PrimaryService {

    @Autowired
    private PrimaryMapper primaryMapper;

    @Autowired
    private PrimaryClassMapper primaryClassMapper;

    @Transactional
    public int create(Primary primary) {
        primaryMapper.create(primary);
        Integer id = primary.getId();
        List<Integer> primaryclassId = primaryMapper.classes(id);
        primaryclassId.forEach(item->{
            PrimaryClass primaryclass = new PrimaryClass();
            primaryclass.setClassId(item);
            primaryclass.setPrimaryId(primary.getId());
            primaryClassMapper.create(primaryclass);
        });
        return 1;
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                primaryMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return primaryMapper.delete(id);
    }

    public int update(Primary primary) {
        primaryMapper.update(primary);
        primaryClassMapper.deleteByPrimaryId(primary.getId());
        Integer id = primary.getId();
        List<Integer> primaryclassId = primaryMapper.classes(id);
        primaryclassId.forEach(item->{
            PrimaryClass primaryclass = new PrimaryClass();
            primaryclass.setClassId(item);
            primaryclass.setPrimaryId(primary.getId());
            primaryClassMapper.create(primaryclass);
        });
        return 1;
    }

    public int updateSelective(Primary primary) {
        return primaryMapper.updateSelective(primary);
    }

    public PageInfo<Primary> query(Primary primary) {
        if(primary != null && primary.getPage() != null){
            PageHelper.startPage(primary.getPage(), primary.getLimit());
        }
        return new PageInfo<Primary>(primaryMapper.query(primary));
    }

    public List<Primary> queryByClassId(Integer classId){
        return primaryMapper.queryByClassId(classId);
    }

    public Primary detail(Integer id) {
        return primaryMapper.detail(id);
    }

    public int count(Primary primary) {
        return primaryMapper.count(primary);
    }

    public List<Integer> classes(Integer id) {
        return primaryMapper.classes(id);
    }
}
