package com.bitzh.whb.dormitory.controller;

import com.bitzh.whb.dormitory.entity.*;
import com.bitzh.whb.dormitory.service.*;
import com.bitzh.whb.dormitory.utils.Result;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;


@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private StudentService studentService;

    @PostMapping("create")
    public Result create(@RequestBody User user){
        String rule1 = "^[a-zA-Z0-9]+$";
        String rule2 = "^[0-9]+$";
        if (!user.getUserno().matches(rule1)) {
            return Result.fail("用户名不能输入中文和特殊符号！");
        } else if (!user.getPhone().matches(rule2)) {
            return Result.fail("手机号只能为数字！");
        } else if (user.getPhone().length() != 11) {
            return Result.fail("手机号为11位！请重新输入");
        } else {
            int flag = userService.create(user);
            if(flag>0){
                return Result.ok();
            }else{
                return Result.fail("数据类型错误！请重新输入");
            }
        }
    }

    @GetMapping("delete")
    public Result delete(String ids){
        int flag = userService.delete(ids);
        if(flag>0){
            return Result.ok();
        }else{
            return Result.fail();
        }
    }

    @PostMapping("update")
    public Result update(@RequestBody User user){
        String rule1 = "^[a-zA-Z0-9]+$";
        String rule2 = "^[0-9]+$";
        if (!user.getUserno().matches(rule1)) {
            return Result.fail("用户名不能输入中文和特殊符号！请重新输入");
        } else if (!user.getPhone().matches(rule2)) {
            return Result.fail("手机号只能为数字！请重新输入");
        } else if (user.getPhone().length() != 11) {
            return Result.fail("手机号为11位！请重新输入");
        } else {
            int flag = userService.updateSelective(user);
            if(flag>0){
                return Result.ok();
            }else{
                return Result.fail("数据类型错误！请重新输入");
            }
        }
    }

    @GetMapping("detail")
    public User detail(Integer id){
        return userService.detail(id);
    }

    @GetMapping("info")
    public Result info(HttpServletRequest request){
        User user = (User)request.getAttribute("user");
        if(user!=null){
            return Result.ok(userService.detail(user.getId()));
        }else{
            Student student = (Student) request.getAttribute("student");
            return Result.ok(studentService.detail(student.getId()));
        }
    }

    @PostMapping("pwd")
    public Result pwd(@RequestBody Map<String,String> map,HttpServletRequest request){
        String oldPassword = map.get("oldPassword");
        String newPassword = map.get("newPassword");
        String confirmPassword = map.get("confirmPassword");
        //用户修改
        if(request.getAttribute("user") != null){
            User user = (User)request.getAttribute("user");
            User entity = userService.detail(user.getId());
            if(entity.getPassword().equals(oldPassword)){
                if (newPassword.length() < 6 || newPassword.length() > 20){
                    return Result.fail("密码长度要在6-20位之间！请重新输入");
                } else {
                    if (newPassword.equals(confirmPassword)){
                        if (newPassword.equals(oldPassword)){
                            return Result.fail("新密码和旧密码一致！请重新修改新密码");
                        } else {
                            User param = new User();
                            param.setId(entity.getId());
                            param.setPassword(newPassword);
                            userService.updatePwd(param);
                            return Result.ok();
                        }
                    }else{
                        return Result.fail("第二次输入密码与第一次不同");
                    }
                }
            }
            else {
                return Result.fail("原密码错误");
            }
        }
        //学生修改
        if(request.getAttribute("student") != null){
            Student student = (Student)request.getAttribute("student");
            Student entity = studentService.detail(student.getId());
            if(entity.getPassword().equals(oldPassword)){
                if (newPassword.length() < 6 || newPassword.length() > 20){
                    return Result.fail("密码长度要在6-20位之间！请重新输入");
                } else {
                    if (newPassword.equals(confirmPassword)){
                        if (newPassword.equals(oldPassword)){
                            return Result.fail("新密码和旧密码一致！请重新修改新密码");
                        } else {
                            Student param = new Student();
                            param.setId(entity.getId());
                            param.setPassword(newPassword);
                            studentService.updateSelective(param);
                            return Result.ok();
                        }
                    }else{
                        return Result.fail("第二次输入密码与第一次不同");
                    }
                }
            }else{
                return Result.fail("原密码错误");
            }
        }
        return Result.ok();
    }

    @PostMapping("query")
    public Map<String,Object> query(@RequestBody User user){
        PageInfo<User> pageInfo = userService.query(user);
        return Result.ok(pageInfo);
    }

}
