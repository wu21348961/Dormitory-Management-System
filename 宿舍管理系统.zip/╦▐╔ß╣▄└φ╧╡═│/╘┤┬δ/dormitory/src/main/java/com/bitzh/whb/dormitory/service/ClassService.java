package com.bitzh.whb.dormitory.service;

import com.bitzh.whb.dormitory.entity.Class;
import com.bitzh.whb.dormitory.mapper.ClassMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class ClassService {

    @Autowired
    private ClassMapper classMapper;

    public int create(Class classes) {
        return classMapper.create(classes);
    }

    public int delete(String ids) {
        String[] arr = ids.split(",");
        int row = 0;
        for (String s : arr) {
            if(!StringUtils.isEmpty(s)){
                classMapper.delete(Integer.parseInt(s));
            row++;
            }
        }
        return row;
    }

    public int delete(Integer id) {
        return classMapper.delete(id);
    }

    public int update(Class classes) {
        return classMapper.update(classes);
    }

    public int updateSelective(Class classes) {
        return classMapper.updateSelective(classes);
    }

    public PageInfo<Class> query(Class classes) {
        if(classes != null && classes.getPage() != null){
            PageHelper.startPage(classes.getPage(),classes.getLimit());
        }
        return new PageInfo<Class>(classMapper.query(classes));
    }

    public Class detail(Integer id) {
        return classMapper.detail(id);
    }

    public int count(Class classes) {
        return classMapper.count(classes);
    }

    public List<Class> queryClassByPrimaryId(Integer primaryId){
        return classMapper.queryClassByPrimaryId(primaryId);
    }
}
